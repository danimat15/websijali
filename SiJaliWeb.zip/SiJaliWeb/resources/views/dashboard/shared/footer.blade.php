<footer class="c-footer">
  <div><a href="https://coreui.io">CoreUI</a> &copy; 2020 creativeLabs.</div>
  <div class="ml-auto">Powered by&nbsp;<a href="https://coreui.io/">CoreUI</a></div>
</footer>